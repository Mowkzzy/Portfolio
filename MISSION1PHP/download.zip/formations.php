<?php

$host = "sql201.infinityfree.com";
$user = "if0_41007284";
$password = "opS5YyRST8";
$database = "if0_41007284_centre_de_formation";

$conn = mysqli_connect($host, $user, $password, $database);


// Vérification
if (!$conn) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

// Requête SQL
$sql = "SELECT COUNT(*) AS total_formations FROM formations";
$result = mysqli_query($conn, $sql);

$sql2 = "SELECT f.intitule, COUNT(m.id_module) 
AS nb_modules 
FROM modules m 
JOIN formations f ON m.id_formation=f.id_formation 
GROUP BY f.intitule";

$result2 = mysqli_query($conn, $sql2);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

      <link rel="stylesheet" href="style.css">

</head>
<body>
    
        <div class="back-container">
    <a href="index.php" class="btn-retour">← Retour à l’accueil</a>
</div>




<h2>Liste de formations</h2>

<table>
    <tr>
        <th>Nombre de Formations</th>
       
    </tr>

    <?php
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>".$row['total_formations']."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>Aucun client trouvé.</td></tr>";
    }

    mysqli_close($conn);
    ?>

</table>


<h2>Nombre de formations</h2>

<table>
    <tr>
        <th>Nombre de Formations</th>
       
    </tr>

    <?php
    if ($result && mysqli_num_rows($result2) > 0) {
        while ($row = mysqli_fetch_assoc($result2)) {
            echo "<tr>";
            echo "<td>".$row['intitule']."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>Aucun client trouvé.</td></tr>";
    }

    ?>

</table>


    
</body>
</html>
