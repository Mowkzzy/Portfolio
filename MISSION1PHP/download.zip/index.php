<?php
// Page d'accueil avec menu simple
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Accueil - Gestion des Réservations</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>

<div class="menu">
    <a href="index.php">Accueil</a>
    <a href="formateurs.php">Formateurs</a>
    <a href="formations.php">Formations</a>
    <a href="étudiants.php">Etudiants</a>
    <a href="notes.php">notes</a>
    <a href="inscription.php">inscriptions</a>



</div>

<div class="content">
    <h1>Bienvenue dans la Gestion du Centre de formation</h1>
    <p>Utilisez le menu pour naviguer.</p>
</div>

</body>
</html>
