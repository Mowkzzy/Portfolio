<?php

$host = "sql201.infinityfree.com";
$user = "if0_41007284";
$password = "opS5YyRST8";
$database = "if0_41007284_centre_de_formation";

$conn = mysqli_connect($host, $user, $password, $database);


// Vérification
if (!$conn) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

// Requête SQL
$sql = "SELECT COUNT(*) AS total_etudiants FROM etudiants;";
$result = mysqli_query($conn, $sql);
// Requête SQL
$sql2 = "SELECT f.intitule, COUNT(i.id_etudiant) AS nb_etudiants 
FROM inscriptions i 
JOIN formations f ON i.id_formation=f.id_formation 
GROUP BY f.intitule;
";
$result2 = mysqli_query($conn, $sql2);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

      <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="back-container">
    <a href="index.php" class="btn-retour">← Retour à l’accueil</a>
</div>




<h2>Nombre total d’étudiants</h2>

<table>
    <tr>
        <th>Nombre Etudiants</th>
    </tr>

    <?php
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>".$row['total_etudiants']."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>Aucun etudiants trouvé.</td></tr>";
    }
    ?>


</table>


<h2>Liste Nombre d’étudiants par formation</h2>
<table>
    <tr>
        <th>formations</th>
        <th>Nombre etudiants</th>
       
    </tr>

    <?php
    if ($result && mysqli_num_rows($result2) > 0) {
        while ($row = mysqli_fetch_assoc($result2)) {
            echo "<tr>";
            echo "<td>".$row['intitule']."</td>";
            echo "<td>".$row['nb_etudiants']."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>Aucun etudiants trouvé.</td></tr>";
    }

    mysqli_close($conn);
    ?>

</table>


    
</body>
</html>
